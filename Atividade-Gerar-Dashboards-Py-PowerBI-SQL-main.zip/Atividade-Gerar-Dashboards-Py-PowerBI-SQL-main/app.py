import streamlit as st
import pandas as pd
import plotly.express as px

st.title("Dashboard de Análise Ambiental (Mata Atlântica e Biomas)")
st.write("Fonte dos dados: Banco de dados de UCs")

# ler csv
tabela = pd.read_csv('cnuc_2024_10_tratado.csv', sep=';')
tabela['Area_ha'] = tabela['Area_ha'].astype(str).str.replace(',', '.')
tabela['Area_ha'] = pd.to_numeric(tabela['Area_ha'], errors='coerce')

# Filtros
st.sidebar.header("Filtros")

estados = sorted(tabela['UF'].unique())
filtro_estado = st.sidebar.multiselect("Escolha os Estados (UF):", estados, default=estados[:5])

esferas = tabela['Esfera Administrativa'].unique()
filtro_esfera = st.sidebar.multiselect("Escolha a Esfera Administrativa:", esferas, default=esferas)

# filtros na tabela
dados = tabela[tabela['UF'].isin(filtro_estado) & tabela['Esfera Administrativa'].isin(filtro_esfera)]

#KPIs
c1, c2, c3 = st.columns(3)

with c1:
    total = len(dados)
    st.metric("Total de UCs Selecionadas", total)

with c2:
    soma = dados['Area_ha'].sum()
    st.metric("Soma da Área (Hectares)", round(soma, 2))

with c3:
    media = dados['Area_ha'].mean()
    st.metric("Tamanho Médio (Hectares)", round(media, 2))

# Primeira fileira de graficos
lado1, lado2 = st.columns(2)

with lado1:
    st.subheader("Ranking de Área por Bioma")
    biomas = dados.groupby('Bioma declarado')['Area_ha'].sum().reset_index()
    g1 = px.bar(biomas, x='Area_ha', y='Bioma declarado', orientation='h', title="Área por Bioma")
    st.plotly_chart(g1)

with lado2:
    st.subheader("Linha do Tempo: Criação das UCs")
    anos = dados.groupby('Ano de Criação').size().reset_index(name='Quantidade')
    g2 = px.line(anos, x='Ano de Criação', y='Quantidade', title="Novas UCs por Ano")
    st.plotly_chart(g2)

#graficos de pizza
baixo1, baixo2 = st.columns(2)

with baixo1:
    st.subheader("Porcentagem de Área por Bioma")
    p1 = px.pie(biomas, values='Area_ha', names='Bioma declarado', title="Divisão da Área por Bioma")
    st.plotly_chart(p1)

with baixo2:
    st.subheader("Quantidade por Esfera Administrativa")
    qtd_esfera = dados.groupby('Esfera Administrativa').size().reset_index(name='Quantidade')
    p2 = px.pie(qtd_esfera, values='Quantidade', names='Esfera Administrativa', title="Divisão por Esfera")
    st.plotly_chart(p2)

#tabela no final consulta dados
st.subheader("Visualização dos Dados Filtrados")
st.write(dados[['ID_UC', 'Nome da UC', 'Esfera Administrativa', 'UF', 'Ano de Criação', 'Area_ha']])

#ideia do aplicativo
st.sidebar.subheader("Ideia de Aplicativo: EcoFiscal")
st.sidebar.write("Notifica os fiscais quando uma UC está sem plano de manejo para agilizar a regularização.")
