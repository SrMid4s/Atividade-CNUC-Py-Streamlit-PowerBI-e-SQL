Grupo: Hebert Velloso, Heitor Araújo, Gustavo Yvo, Gabriel Ladeira.

#Documentação da Análise Exploratória de Dados com estatísticas descritivas e respostas fundamentadas às perguntas de negócio.

1. Qual bioma tem a maior área protegida e onde existem mais unidades?

 Resposta: A Amazônia concentra a maior extensão total em hectares por ter reservas gigantescas. Já a Mata Atlântica possui uma das maiores quantidades de unidades criadas, mas com tamanhos menores devido à ocupação urbana.

2. Como foi o ritmo de criação das Unidades de Conservação ao longo dos anos?

 A criação não foi constante, tendo picos fortes entre os anos 1980 e 2000 por conta de novas leis ambientais. Nos últimos anos, o ritmo diminuiu, mudando o foco para a fiscalização das áreas que já existem.

3. Qual nível de governo (Federal, Estadual ou Municipal) cuida da maior parte das reservas?

 As esferas Federal e Estadual administram as maiores áreas territoriais do país. Já os Municípios são responsáveis por várias unidades menores, focadas na proteção local e urbana.

4. Por que os dados provam que o aplicativo EcoFiscal é necessário?

 Como existem milhares de reservas espalhadas pelo país e muitas não têm Plano de Manejo, o controle manual falha. O EcoFiscal automatiza esses avisos para ajudar os fiscais a regularizarem as áreas mais rápido.



Consultar a parte 1 dos tratamento dos dados orginais abaixo:

https://github.com/HebertVelloso123/Atividade-Avaliativa-tirar-duplicatas-e-dados-faltantes
