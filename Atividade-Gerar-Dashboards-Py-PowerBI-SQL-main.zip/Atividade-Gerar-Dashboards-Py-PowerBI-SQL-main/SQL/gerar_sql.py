import os
import pandas as pd
import numpy as np

# Configurações de arquivos
ARQUIVO_CSV_TRATADO = 'cnuc_2024_10_tratado.csv'
ARQUIVO_SQL_SAIDA = 'importar_cnuc_linhas.sql'

def converter_csv_para_inserts():
    if not os.path.exists(ARQUIVO_CSV_TRATADO):
        print(f"[ERRO] O arquivo '{ARQUIVO_CSV_TRATADO}' não existe. Gere o CSV primeiro.")
        return

    print("-> Lendo o arquivo CSV tratado...")
    df = pd.read_csv(ARQUIVO_CSV_TRATADO, sep=';', encoding='utf-8', low_memory=False)

    # LIMPEZA RIGOROSA DE CABEÇALHOS (Remove + e outros operadores matemáticos)
    novas_colunas = []
    for col in df.columns.astype(str):
        col_limpa = col.strip()
        
        # Remove acentuações e caracteres especiais críticos
        col_limpa = (col_limpa.replace('á', 'a').replace('ã', 'a').replace('â', 'a')
                              .replace('é', 'e').replace('ê', 'e')
                              .replace('í', 'i')
                              .replace('ó', 'o').replace('õ', 'o').replace('ô', 'o')
                              .replace('ú', 'u')
                              .replace('ç', 'c')
                              .replace('Á', 'A').replace('É', 'E').replace('Í', 'I').replace('Ó', 'O').replace('Ú', 'U'))
        
        # Trata a coluna de Fonte da Área
        if "Fonte_da_Area" in col_limpa or "Fonte da Area" in col_limpa:
            col_limpa = "Fonte_da_Area_SHP_Ato_legal"
        
        # Substitui o operador matemático + por uma palavra segura
        col_limpa = col_limpa.replace('+', '_e_')
        
        # Remove pontuações e caracteres que quebram o interpretador do MySQL
        col_limpa = (col_limpa.replace(' ', '_')
                              .replace('/', '_')
                              .replace('%', 'pct')
                              .replace(':', '')
                              .replace('(', '')
                              .replace(')', '')
                              .replace('-', '_')
                              .replace('=', '_')
                              .replace(',', '_')
                              .replace('º', ''))
        
        # Remove underlines duplicados que possam ter surgido nas substituições
        while "__" in col_limpa:
            col_limpa = col_limpa.replace("__", "_")
            
        novas_colunas.append(col_limpa)
    
    df.columns = novas_colunas

    print(f"-> Convertendo {len(df)} registros em linhas de INSERT SQL com colunas válidas...")

    with open(ARQUIVO_SQL_SAIDA, 'w', encoding='utf-8') as f:
        f.write("CREATE DATABASE IF NOT EXISTS cnuc_db;\n")
        f.write("USE cnuc_db;\n")
        f.write("DROP TABLE IF EXISTS tb_cnuc_tratado;\n\n")
        
        # Escreve a estrutura da tabela livre de operadores aritméticos
        f.write("CREATE TABLE tb_cnuc_tratado (\n")
        for coluna in df.columns:
            if df[coluna].dtype in [np.int64, np.int32]:
                f.write(f"    {coluna} INT,\n")
            elif df[coluna].dtype in [np.float64, np.float32]:
                f.write(f"    {coluna} DECIMAL(18,4),\n")
            elif df[coluna].dtype == bool:
                f.write(f"    {coluna} BOOLEAN,\n")
            else:
                f.write(f"    {coluna} TEXT,\n")
        f.write("    PRIMARY KEY (ID_UC)\n")
        f.write(") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n")

        colunas_str = ", ".join(df.columns)
        
        for _, row in df.iterrows():
            valores_valores = []
            for col in df.columns:
                val = row[col]
                
                if pd.isna(val) or val == 'Não Informado':
                    valores_valores.append("NULL")
                elif isinstance(val, (int, float, np.integer, np.floating)):
                    if isinstance(val, float) and np.isnan(val):
                        valores_valores.append("NULL")
                    else:
                        valores_valores.append(str(val))
                elif isinstance(val, bool):
                    valores_valores.append(str(int(val)))
                else:
                    texto_escapado = str(val).replace("'", "''")
                    valores_valores.append(f"'{texto_escapado}'")
            
            valores_str = ", ".join(valores_valores)
            f.write(f"INSERT INTO tb_cnuc_tratado ({colunas_str}) VALUES ({valores_str});\n")

    print(f"   [SUCESSO] Novo script SQL gerado e validado em: '{ARQUIVO_SQL_SAIDA}'")

if __name__ == "__main__":
    converter_csv_para_inserts()
